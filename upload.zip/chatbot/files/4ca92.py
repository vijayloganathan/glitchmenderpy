v=10
print(v