let editor;
var inputs = $("#input");

window.onload = function() {
    editor = ace.edit("editor");
    editor.setTheme("ace/theme/cobalt");
    editor.session.setMode("ace/mode/python");

    const schat ="Hai!,I am  Glitch Mender"
            var server = document.createElement("h4");
            var servertype = document.createTextNode(schat);
            var brea = document.createElement("br");
            server.appendChild(servertype);
            server.appendChild(brea);
            chatinterface.appendChild(server);
            scroll();
             let speech = new SpeechSynthesisUtterance();
             speech.lang = "en-US";
             speech.text = schat;
             speech.volume =1;
             speech.rate = 1;
             speech.pitch = 1;

             window.speechSynthesis.speak(speech);

             defaultmessage()

             
             
}

$("#run").click(function(){
    $.ajax({
        url: "server.php",
        method: "POST",
        data: {
            code: editor.getSession().getValue(),
            input: inputs.val()
        },
        success: function(response){
            $(".code_output").text(response);
        }
    })

})